<?php
    /**
     * Your Twitter App Info
     */
    
    // Consumer Key
    define('CONSUMER_KEY', 'QET8tJqFQfzLu4vgEdmi6w');
    define('CONSUMER_SECRET', 'ka78PZ9k8j6pV92vVmjRIW2q6QN0f9SwjR2WcKEfs');

    // User Access Token
    define('ACCESS_TOKEN', '1641190074-oWzDMK9riga5x2KMrHMmhQHH0RX7oF8BOar2tJ7');
    define('ACCESS_SECRET', 'LHPnZMwmdm5g8gpLCfco3l4UcL27oVIvH6u1rJUoTM4');